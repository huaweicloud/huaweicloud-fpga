================
 Policy History
================

* `Discussion from Havana Summit <https://etherpad.openstack.org/p/havana-oslo-i18n-strategy>`__
* `Discussion from Icehouse Summit <https://etherpad.openstack.org/p/icehouse-oslo-i18n-policies>`__
* `Discussion from Juno Summit <https://etherpad.openstack.org/p/juno-cross-project-i18n>`__
* `I18n team wiki page <https://wiki.openstack.org/wiki/I18n>`__
* `LoggingStandards wiki page <https://wiki.openstack.org/wiki/LoggingStandards>`__

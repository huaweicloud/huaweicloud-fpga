positional package
==================

Module contents
---------------

.. automodule:: positional
    :members:
    :undoc-members:
    :show-inheritance:

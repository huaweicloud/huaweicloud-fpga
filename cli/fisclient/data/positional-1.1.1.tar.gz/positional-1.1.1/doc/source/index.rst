Positional decorator documentation
==================================

Contents:

.. toctree::
   :maxdepth: 1

   api/modules

Usage
=====

.. include:: ../../README.rst


Release Notes
=============

.. toctree::
   :maxdepth: 1

   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

